import { Bundle } from "../../models/bundle/employee_department.js"
import { Departments } from "../../models/department.js";
import { Employee } from "../../models/employee.js";


export const add_bundle = (req, res) => {
    Bundle.create({ ...req.body }).then(res.send('Greate!!! You bundle employes and department')).catch(res.send("OOPS!!!an error occurred please enter a valid value"))
} 
export const get_bundle = (req, res) => {
    Bundle.findAll({ raw: true }).then(bundle => {
        res.json(bundle);
    }).catch(err => console.log(err));
}

export const bundle_employee = (req, res) => {
    Employee.findOne({ include: Departments }).then(data=>{
        if(data.length!=0){res.send(data)}else{res.send("Error 404 not found")}})
    
}