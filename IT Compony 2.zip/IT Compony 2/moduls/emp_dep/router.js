import express from 'express';
import { add_bundle, bundle_employee, get_bundle} from './controller.js';

const router = express.Router();



router.post('/add_bundle',add_bundle)
router.get('/get_bundle', get_bundle);
router.get('/bundle_employee', bundle_employee);


export default router;