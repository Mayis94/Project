
import { Employee } from "../../models/employee.js"


export const add_employee = (req, res) => {
    Employee.create(req.body).then(res.send("Greate!!! You added employee")).catch(res.send("OOPS!!!an error occurred please enter a valid value"))
}
export const get_employee = (req, res) => {
    Employee.findAll({ raw: true }).then(eployee => {
        res.json(eployee);
    }).catch(err => console.log(err));
}
