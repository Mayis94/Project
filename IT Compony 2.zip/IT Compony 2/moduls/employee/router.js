import express from 'express';
import { add_employee, get_employee} from './controller.js';

const router = express.Router();



router.post('/add_employee',add_employee)
router.get('/get_employee', get_employee);


export default router;