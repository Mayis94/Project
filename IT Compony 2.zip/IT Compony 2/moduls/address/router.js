import express from 'express';
import { add_address, get_address, search_address, update} from './controller.js';

const router = express.Router();



router.post('/add_address',add_address)
router.get('/get_address', get_address);
router.get('/search_address', search_address);
router.post('/update_address/:id',update)



export default router;