import { Address } from "../../models/address.js"

export const add_address = (req, res) => {
    Address.create(req.body)
    .then((data) => res.send('Greate!!! You added address'))
    .catch((error) =>  res.send('OOPS!!!an error occurred please enter a valid value'))
}
export const get_address = (req, res) => {
    Address.findAll({ raw: true }).then(address => {
        res.json(address);
    }).catch((error) =>  res.send('OOPS!!! data is empty'))
}

export const search_address = (req, res) => {
    Address.findAll({where:req.query.name,raw: true })
    .then(users=>{
     res.send(users)
    }).catch(err=>console.log(err))
}
export const update = (req, res) => {
    Address.update(
       req.body,
        {
            where: {
                id: req.params.id
            },
        }
    ).then((data) => res.send('Greate!!! You update address'))
    .catch((error) =>  res.send('OOPS!!!please write existing value'))

}

export const del =(req,res)=>{
    Address.destroy({
    where: {
        id: req.body.id
    },
  }).then(user => {
    res.json(user)
})
}