import express from 'express';
import { add_position, get_employeeBYpositionId, get_position} from './controller.js';

const router = express.Router();



router.post('/add_position',add_position)
router.get('/get_position', get_position);
router.get('/get_employeeBYpositionId/:id', get_employeeBYpositionId);

export default router;