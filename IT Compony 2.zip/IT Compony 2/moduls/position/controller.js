import { Employee } from "../../models/employee.js";
import  Position  from "../../models/position.js"

export const add_position = (req, res) => {
    console.log('llllll');
    console.log(req.body);
    Position.create(req.body).then(res.send('Greate!!! You added position')).catch(res.send("OOPS!!!an error occurred please enter a valid value"))
}
export const get_position = (req, res) => {
    Position.findAll({ raw: true }).then(position => {
        res.json(position);
    }).catch(err => console.log(err));
}

export const get_employeeBYpositionId = (req, res) => {
    Employee.findAll({ include: Position,where:{position_id:req.params.id}})
    .then(data=>{
        if(data.length!=0){res.send(data)}else{res.send("Error 404 not found")}})
        
}