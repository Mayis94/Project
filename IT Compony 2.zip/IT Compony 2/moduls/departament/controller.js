import { Departments } from "../../models/department.js"
import { Employee } from "../../models/employee.js";

export const add_department = (req, res) => {
    Departments.create({ ...req.body }).then(res.send('Greate!!! You added department')).catch(res.send("OOPS!!!an error occurred please enter a valid value"))
}
export const get_department = (req, res) => {
    Departments.findAll({ raw: true }).then(department => {
        res.json(department);
    }).catch(err => console.log(err));
}
export const get_employeeBYdepartment = (req, res) => {
    Departments.findAll({ include: Employee,where:{id:req.params.id} }).then(data=>res.send(data))
        
    
}