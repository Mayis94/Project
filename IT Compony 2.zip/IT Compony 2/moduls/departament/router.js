import express from 'express';
import { add_department, get_department, get_employeeBYdepartment} from './controller.js';

const router = express.Router();



router.post('/add_department',add_department)
router.get('/get_department', get_department);
router.get('/get_employeeBYdepartment/:id', get_employeeBYdepartment);

export default router;