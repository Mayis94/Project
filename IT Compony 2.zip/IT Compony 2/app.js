import express from "express";
import EmployeeRouter from "./moduls/employee/router.js";
import AddressRouter from "./moduls/address/router.js";
import DepartmentRouter from "./moduls/departament/router.js";
import PositionRouter from "./moduls/position/router.js";
import BundleRouter from "./moduls/emp_dep/router.js";
import bodyParser from "body-parser";

const app = express();

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use('/employee/', EmployeeRouter);
app.use('/address/', AddressRouter);
app.use('/department/', DepartmentRouter);
app.use('/position/', PositionRouter);
app.use('/bundle/', BundleRouter);

app.listen(3070);