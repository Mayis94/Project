
import Sequelize, {Model} from "sequelize";
import { sequelize } from './conect/index.js';
import { Address } from "./address.js";
import Position from "./position.js";


export class Employee extends Model {}
Employee.init({
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    first_name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    last_name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    surname: {
        type: Sequelize.STRING,
        allowNull: false
    },
    selary: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
     age: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    birthday: {
        type: Sequelize.STRING,
        allowNull: false
    },
    pasport_seria: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    social_card: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    bank_card: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    cv: {
        type: Sequelize.STRING,
        allowNull: false
    },
}, {
    sequelize,
    modelName: "employee"
});



Employee.belongsTo(Address,{foreignKey:"address_id",onDelete:"cascade"});
Employee.belongsTo(Position, {
    foreignKey: "position_id",
});
Employee.sync()