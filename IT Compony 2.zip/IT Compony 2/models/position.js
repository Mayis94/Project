import Sequelize, { Model } from "sequelize";
import { sequelize } from './conect/index.js';
import { Employee } from "./employee.js";


export default class Position extends Model { }
Position.init({
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    position: {
        type: Sequelize.STRING,
        allowNull: false
    }

}, {
    sequelize,
    modelName: "position"
});

Position.hasMany(Employee)
Position.sync()

