import Sequelize, {Model} from "sequelize";
import { sequelize } from '../conect/index.js';
import { Departments } from "../department.js";
import { Employee } from "../employee.js";

export class Bundle  extends Model {}
Bundle.init({
    id: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false
    },
    grade: {                 
      type: Sequelize.INTEGER,
      allowNull: false
    }},
    {

        sequelize,
        modelName: "emp_dep"
    });
    
 
Employee.belongsToMany(Departments, {through: Bundle});
Departments.belongsToMany(Employee, {through: Bundle});
Bundle.sync()