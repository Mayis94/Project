import Sequelize, {Model} from "sequelize";
import { sequelize } from './conect/index.js';

export class Address extends Model {}
Address.init({
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    country: {
        type: Sequelize.STRING,
        allowNull: false
    },
    city: {
        type: Sequelize.STRING,
        allowNull: false
    },
    street: {
        type: Sequelize.STRING,
        allowNull: false
    },
    building: {
        type: Sequelize.STRING,
        allowNull: false
    },
    flat: {
        type: Sequelize.STRING,
        allowNull: false
    },
}, {
    sequelize,
    modelName: "address"
});

Address.sync()