import Sequelize from "sequelize";

export const sequelize = new Sequelize("company", "root", "mango1964", {
    dialect: "postgres",
    host: "localhost",
    define: {
        timestamps: false
    }
});
