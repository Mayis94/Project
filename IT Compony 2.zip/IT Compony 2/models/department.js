import Sequelize, {Model} from "sequelize";
import { sequelize } from './conect/index.js';

export class Departments extends Model {}
Departments .init({
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    department: {
        type: Sequelize.STRING,
        allowNull: false
    }

}, {
    sequelize,
    modelName: "department"
});


Departments.sync()